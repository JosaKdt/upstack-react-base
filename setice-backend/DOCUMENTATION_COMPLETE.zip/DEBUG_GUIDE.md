# 🔧 GUIDE DE DÉBOGAGE - Tests d'acceptation

## 📊 ANALYSE DES ERREURS

### **Résumé des tests**
```
✅ 10 tests passés (authentification, doublons, consultation)
❌ 21 tests échoués (créations + autorisations)
```

---

## 🔍 PROBLÈMES IDENTIFIÉS

### **Problème #1 : Créations retournent 400 au lieu de 201**

**Tests concernés :**
- Créer formateur → 400 (attendu: 201)
- Créer promotion → 400 (attendu: 201)
- Créer étudiant → 400 (attendu: 201)
- Créer espace → 400 (attendu: 201)

**Cause probable :**
Les schémas Zod rejettent les données envoyées.

**Solutions à tester :**

#### Solution A : Vérifier les schémas Zod
```powershell
# Regarder ce que les schémas attendent
code src/schemas/formateur.schema.ts
code src/schemas/promotion.schema.ts
```

**Points à vérifier :**
- Champs requis vs optionnels
- Format des données (string, number, etc.)
- Validations personnalisées (email, regex, etc.)

#### Solution B : Logger les erreurs Zod
Dans chaque route `app/api/v1/*/create/route.ts`, modifier :

```typescript
export async function POST(req: Request) {
  try {
    const body = await req.json()
    
    // 🔍 AJOUTER CES LOGS
    console.log('📥 Body reçu:', body)
    
    const data = createXSchema.parse(body)
    
    // ... reste du code
  } catch (e: any) {
    // 🔍 LOGGER L'ERREUR COMPLÈTE
    console.error('❌ Erreur validation:', e)
    
    return NextResponse.json({ 
      success: false, 
      error: e.message,
      details: e.errors // Si c'est une erreur Zod
    }, { status: 400 })
  }
}
```

---

### **Problème #2 : Middleware d'auth ne bloque pas (400 au lieu de 401)**

**Tests concernés :**
- Créer formateur sans auth → 400 (attendu: 401)
- Créer promotion sans auth → 400 (attendu: 401)
- Créer étudiant sans auth → 400 (attendu: 401)

**Cause probable :**
Le middleware d'authentification n'est pas appelé, ou retourne une erreur de validation avant de vérifier l'auth.

**Solutions à tester :**

#### Solution A : Vérifier l'ordre des vérifications
Dans chaque route, l'auth DOIT être vérifiée EN PREMIER :

```typescript
export async function POST(req: Request) {
  try {
    // ✅ AUTH EN PREMIER !
    const user = requireRole(req, ['DIRECTEUR_ETUDES'])
    
    // Ensuite validation
    const body = await req.json()
    const data = createXSchema.parse(body)
    
    // ... reste du code
  } catch (e: any) {
    if (e.message === 'UNAUTHORIZED' || e.message === 'NO_TOKEN') {
      return NextResponse.json({ success: false, error: e.message }, { status: 401 })
    }
    if (e.message === 'FORBIDDEN') {
      return NextResponse.json({ success: false, error: e.message }, { status: 403 })
    }
    // Autres erreurs (validation, etc.)
    return NextResponse.json({ success: false, error: e.message }, { status: 400 })
  }
}
```

#### Solution B : Vérifier le middleware
```powershell
code src/middleware/auth.middleware.ts
```

**Vérifier que :**
- `requireRole()` throw une erreur avec `message: 'UNAUTHORIZED'`
- L'erreur est bien catchée dans les routes
- Le status 401 est retourné

---

### **Problème #3 : Structure de réponse (`data.data` undefined)**

**Tests concernés :**
- Tests qui vérifient `data.data.nom`, `data.data.id`, etc.

**Cause probable :**
Le backend ne retourne pas `{ success: true, data: { ... } }` mais une structure différente.

**Solutions :**

#### Solution A : Vérifier la structure réelle
Utiliser le script de diagnostic pour voir la VRAIE structure :

```powershell
# Copier diagnostic.ts dans le projet
copy C:\Users\folaw\Downloads\diagnostic.ts C:\Users\folaw\upstack-react-base\setice-backend\

# Exécuter
npx ts-node diagnostic.ts
```

#### Solution B : Unifier les réponses
Dans chaque service, s'assurer de retourner :

```typescript
// ✅ BON
return { success: true, data: result }

// ❌ FAUX
return result  // Directement sans wrapper
```

Et dans chaque route :

```typescript
return NextResponse.json({ 
  success: true, 
  data: result 
}, { status: 201 })
```

---

## 🚀 PLAN D'ACTION RAPIDE

### **Étape 1 : Diagnostic (5 min)**

```powershell
# Terminal 1 : Serveur avec logs
cd C:\Users\folaw\upstack-react-base\setice-backend
$env:DEBUG="*"
npm run dev

# Terminal 2 : Tester un endpoint manuellement
curl -X POST http://localhost:3000/api/v1/formateurs/create `
  -H "Content-Type: application/json" `
  -H "Authorization: Bearer <TON_TOKEN>" `
  -d '{\"nom\":\"TEST\",\"prenom\":\"Debug\",\"email\":\"debug@test.com\",\"specialite\":\"Test\"}'
```

**Observer :**
- Quel status code ? (201, 400, 401 ?)
- Quelle structure de réponse ?
- Y a-t-il des logs d'erreur ?

---

### **Étape 2 : Corriger le plus urgent (10 min)**

#### Cas A : Si c'est un problème de schéma Zod

Ouvrir `src/schemas/formateur.schema.ts` et vérifier :

```typescript
export const createFormateurSchema = z.object({
  nom: z.string(),
  prenom: z.string(),
  email: z.string().email(),
  specialite: z.string(),
  // ⚠️ Y a-t-il d'autres champs requis ?
})
```

Rendre certains champs optionnels si nécessaire :

```typescript
export const createFormateurSchema = z.object({
  nom: z.string(),
  prenom: z.string(),
  email: z.string().email(),
  specialite: z.string().optional(), // Si optionnel
})
```

#### Cas B : Si c'est un problème d'auth

Ouvrir chaque route et vérifier que :

```typescript
export async function POST(req: Request) {
  try {
    // 🔥 CETTE LIGNE DOIT ÊTRE EN PREMIER !
    const user = requireRole(req, ['DIRECTEUR_ETUDES'])
    
    // ... reste du code
  } catch (e: any) {
    // 🔥 GÉRER LES ERREURS D'AUTH SÉPARÉMENT !
    if (e.message === 'UNAUTHORIZED') {
      return NextResponse.json({ success: false, error: 'UNAUTHORIZED' }, { status: 401 })
    }
    // ... autres erreurs
  }
}
```

---

### **Étape 3 : Relancer les tests (2 min)**

```powershell
npm run test:sprint1
```

**Objectif :** Voir combien de tests passent maintenant !

---

## 📝 CHECKLIST DE DÉBOGAGE

### Routes `/formateurs/create`, `/promotions/create`, etc.

- [ ] Auth vérifiée EN PREMIER
- [ ] Erreurs 401/403 retournées pour les problèmes d'auth
- [ ] Schémas Zod correspondent aux données envoyées
- [ ] Réponse au format `{ success: true, data: {...} }`
- [ ] Status 201 pour les créations réussies

### Middleware `auth.middleware.ts`

- [ ] `requireRole()` throw une erreur `UNAUTHORIZED` si pas de token
- [ ] `requireRole()` throw une erreur `FORBIDDEN` si mauvais rôle
- [ ] Le header `Authorization: Bearer <token>` est bien extrait

### Schémas Zod

- [ ] Tous les champs requis sont présents dans les tests
- [ ] Les types correspondent (string, number, etc.)
- [ ] Pas de validation trop stricte (regex, min/max, etc.)

---

## 🔍 COMMANDES UTILES

### Voir les logs en temps réel
```powershell
npm run dev | Select-String "error|ERROR|❌"
```

### Tester un endpoint manuellement
```powershell
# Login
$response = Invoke-RestMethod -Uri "http://localhost:3000/api/v1/auth/login" `
  -Method POST `
  -ContentType "application/json" `
  -Body '{"email":"directeur@setice.edu","password":"password123"}'

$token = $response.data.token

# Créer un formateur
Invoke-RestMethod -Uri "http://localhost:3000/api/v1/formateurs/create" `
  -Method POST `
  -ContentType "application/json" `
  -Headers @{Authorization="Bearer $token"} `
  -Body '{"nom":"TEST","prenom":"Debug","email":"debug@test.com","specialite":"Test"}'
```

### Vérifier la structure d'une table
```powershell
psql -U postgres -d setice_db
\d formateurs
\d promotions
```

---

## 💡 SOLUTIONS RAPIDES

### Solution 1 : Désactiver temporairement l'auth pour debug

Dans les routes, commenter temporairement :

```typescript
export async function POST(req: Request) {
  try {
    // const user = requireRole(req, ['DIRECTEUR_ETUDES']) // ⚠️ TEMPORAIRE
    
    const body = await req.json()
    const data = createXSchema.parse(body)
    // ... reste
  }
}
```

**Relancer les tests** → Si ça passe, le problème vient de l'auth !

### Solution 2 : Logs de debugging partout

Ajouter des logs dans TOUTES les routes :

```typescript
export async function POST(req: Request) {
  console.log('🔥 [Route /formateurs/create] START')
  
  try {
    console.log('🔒 Vérification auth...')
    const user = requireRole(req, ['DIRECTEUR_ETUDES'])
    console.log('✅ Auth OK, user:', user.email)
    
    const body = await req.json()
    console.log('📥 Body:', body)
    
    const data = createXSchema.parse(body)
    console.log('✅ Validation OK')
    
    const result = await createFormateur(data)
    console.log('✅ Formateur créé:', result.id)
    
    return NextResponse.json({ success: true, data: result }, { status: 201 })
  } catch (e: any) {
    console.error('❌ Erreur:', e.message)
    // ... gestion erreur
  }
}
```

**Relancer les tests** → Observer les logs pour comprendre où ça bloque !

---

## 🎯 OBJECTIF

Faire passer les 21 tests qui échouent en identifiant et corrigeant :

1. ✅ Structure des réponses
2. ✅ Ordre des vérifications (auth first!)
3. ✅ Schémas Zod alignés avec les données

---

**Commence par le diagnostic, envoie-moi les résultats et on corrige ! 💪**
