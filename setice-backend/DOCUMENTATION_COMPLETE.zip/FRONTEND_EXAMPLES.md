# 💻 EXEMPLES DE CODE - FRONTEND SETICE

## 🔧 CONFIGURATION

### 1. Créer un service API (api.service.ts)

```typescript
// src/services/api.service.ts

const API_BASE_URL = 'http://localhost:3000/api/v1'

interface ApiResponse<T> {
  success: boolean
  data?: T
  error?: string
}

export class ApiService {
  private static token: string | null = null

  static setToken(token: string) {
    this.token = token
    localStorage.setItem('setice_token', token)
  }

  static getToken(): string | null {
    if (!this.token) {
      this.token = localStorage.getItem('setice_token')
    }
    return this.token
  }

  static clearToken() {
    this.token = null
    localStorage.removeItem('setice_token')
  }

  private static async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<ApiResponse<T>> {
    const token = this.getToken()
    
    const headers: HeadersInit = {
      'Content-Type': 'application/json',
      ...(token && { Authorization: `Bearer ${token}` }),
      ...options.headers,
    }

    try {
      const response = await fetch(`${API_BASE_URL}${endpoint}`, {
        ...options,
        headers,
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || 'Une erreur est survenue')
      }

      return data
    } catch (error) {
      console.error('API Error:', error)
      throw error
    }
  }

  static get<T>(endpoint: string): Promise<ApiResponse<T>> {
    return this.request<T>(endpoint, { method: 'GET' })
  }

  static post<T>(endpoint: string, body: any): Promise<ApiResponse<T>> {
    return this.request<T>(endpoint, {
      method: 'POST',
      body: JSON.stringify(body),
    })
  }

  static put<T>(endpoint: string, body: any): Promise<ApiResponse<T>> {
    return this.request<T>(endpoint, {
      method: 'PUT',
      body: JSON.stringify(body),
    })
  }

  static delete<T>(endpoint: string): Promise<ApiResponse<T>> {
    return this.request<T>(endpoint, { method: 'DELETE' })
  }
}
```

---

## 🔐 AUTHENTIFICATION

### 2. Service d'authentification (auth.service.ts)

```typescript
// src/services/auth.service.ts

import { ApiService } from './api.service'

export interface User {
  id: string
  email: string
  nom: string
  prenom: string
  role: 'DIRECTEUR_ETUDES' | 'FORMATEUR' | 'ETUDIANT'
  motDePasseTemporaire: boolean
  createdAt: string
  updatedAt: string
}

export interface LoginResponse {
  user: User
  token: string
}

export class AuthService {
  static async login(email: string, password: string): Promise<User> {
    const response = await ApiService.post<LoginResponse>('/auth/login', {
      email,
      password,
    })

    if (response.success && response.data) {
      ApiService.setToken(response.data.token)
      return response.data.user
    }

    throw new Error('Login failed')
  }

  static logout() {
    ApiService.clearToken()
  }

  static isAuthenticated(): boolean {
    return ApiService.getToken() !== null
  }
}
```

---

## 📚 ESPACES PÉDAGOGIQUES

### 3. Service des espaces (espaces.service.ts)

```typescript
// src/services/espaces.service.ts

import { ApiService } from './api.service'

export interface EspacePedagogique {
  id: string
  annee: string
  promotion: {
    id: string
    code: string
    libelle: string
  }
  matiere: {
    id: string
    libelle: string
    code?: string
  }
  formateur: {
    id: string
    nom: string
    prenom: string
    email: string
  }
  etudiants: Array<{
    id: string
    nom: string
    prenom: string
    matricule: string
  }>
}

export class EspacesService {
  static async list(): Promise<EspacePedagogique[]> {
    const response = await ApiService.get<EspacePedagogique[]>(
      '/espaces-pedagogique/list'
    )
    return response.data || []
  }

  static async create(data: {
    promotionId: string
    matiereId: string
    formateurId: string
    annee: string
  }): Promise<EspacePedagogique> {
    const response = await ApiService.post<EspacePedagogique>(
      '/espaces-pedagogique/create',
      data
    )
    if (!response.data) throw new Error('Failed to create espace')
    return response.data
  }

  static async assignFormateur(
    espacePedagogiqueId: string,
    formateurId: string
  ): Promise<void> {
    await ApiService.post('/espaces-pedagogique/assign-formateur', {
      espacePedagogiqueId,
      formateurId,
    })
  }

  static async addEtudiants(
    espacePedagogiqueId: string,
    promotionId: string
  ): Promise<{ inscrits: number; dejaInscrits: number; total: number }> {
    const response = await ApiService.post<{
      inscrits: number
      dejaInscrits: number
      total: number
    }>('/espaces-pedagogique/add-etudiants', {
      espacePedagogiqueId,
      promotionId,
    })
    if (!response.data) throw new Error('Failed to add students')
    return response.data
  }
}
```

---

## 🎓 AUTRES ENTITÉS

### 4. Service des promotions (promotions.service.ts)

```typescript
// src/services/promotions.service.ts

import { ApiService } from './api.service'

export interface Promotion {
  id: string
  code: string
  libelle: string
  annee: string
  createdAt: string
  updatedAt: string
}

export class PromotionsService {
  static async create(data: {
    code: string
    libelle: string
    annee: string
  }): Promise<Promotion> {
    const response = await ApiService.post<Promotion>(
      '/promotions/create',
      data
    )
    if (!response.data) throw new Error('Failed to create promotion')
    return response.data
  }
}
```

### 5. Service des formateurs (formateurs.service.ts)

```typescript
// src/services/formateurs.service.ts

import { ApiService } from './api.service'

export interface Formateur {
  id: string
  nom: string
  prenom: string
  email: string
  specialite: string
  createdAt: string
  updatedAt: string
}

export class FormateursService {
  static async create(data: {
    nom: string
    prenom: string
    email: string
    specialite: string
  }): Promise<Formateur> {
    const response = await ApiService.post<Formateur>(
      '/formateurs/create',
      data
    )
    if (!response.data) throw new Error('Failed to create formateur')
    return response.data
  }
}
```

### 6. Service des étudiants (etudiants.service.ts)

```typescript
// src/services/etudiants.service.ts

import { ApiService } from './api.service'

export interface Etudiant {
  id: string
  nom: string
  prenom: string
  email: string
  matricule: string
  promotionId: string
  createdAt: string
  updatedAt: string
}

export class EtudiantsService {
  static async create(data: {
    nom: string
    prenom: string
    email: string
    promotionId: string
    matricule: string
  }): Promise<Etudiant> {
    const response = await ApiService.post<Etudiant>(
      '/etudiants/create',
      data
    )
    if (!response.data) throw new Error('Failed to create etudiant')
    return response.data
  }
}
```

---

## 🎨 EXEMPLES D'UTILISATION (REACT)

### 7. Page de Login

```tsx
// src/pages/Login.tsx

import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { AuthService } from '../services/auth.service'

export function LoginPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const navigate = useNavigate()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    try {
      const user = await AuthService.login(email, password)
      console.log('Logged in as:', user.email)
      navigate('/dashboard')
    } catch (err) {
      setError('Email ou mot de passe incorrect')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <div className="max-w-md w-full bg-white p-8 rounded-lg shadow-lg">
        <h1 className="text-2xl font-bold mb-6 text-center">
          SETICE - Connexion
        </h1>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="directeur@setice.edu"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">
              Mot de passe
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="••••••••"
              required
            />
          </div>

          {error && (
            <div className="bg-red-50 text-red-600 p-3 rounded-lg text-sm">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? 'Connexion...' : 'Se connecter'}
          </button>
        </form>
      </div>
    </div>
  )
}
```

### 8. Page Liste des Espaces

```tsx
// src/pages/EspacesList.tsx

import { useEffect, useState } from 'react'
import { EspacesService, EspacePedagogique } from '../services/espaces.service'

export function EspacesListPage() {
  const [espaces, setEspaces] = useState<EspacePedagogique[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    loadEspaces()
  }, [])

  const loadEspaces = async () => {
    try {
      const data = await EspacesService.list()
      setEspaces(data)
    } catch (err) {
      setError('Erreur lors du chargement des espaces')
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return <div className="p-8 text-center">Chargement...</div>
  }

  if (error) {
    return <div className="p-8 text-center text-red-600">{error}</div>
  }

  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold mb-6">Espaces Pédagogiques</h1>

      <div className="grid gap-4">
        {espaces.map((espace) => (
          <div
            key={espace.id}
            className="bg-white p-6 rounded-lg shadow hover:shadow-lg transition"
          >
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-xl font-semibold text-blue-600">
                  {espace.matiere.libelle}
                </h3>
                <p className="text-gray-600 mt-1">
                  {espace.promotion.libelle}
                </p>
                <p className="text-sm text-gray-500 mt-2">
                  Formateur: {espace.formateur.prenom} {espace.formateur.nom}
                </p>
                <p className="text-sm text-gray-500">
                  {espace.etudiants.length} étudiant(s) inscrit(s)
                </p>
              </div>
              <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded">
                {espace.annee}
              </span>
            </div>
          </div>
        ))}
      </div>

      {espaces.length === 0 && (
        <div className="text-center text-gray-500 mt-8">
          Aucun espace pédagogique disponible
        </div>
      )}
    </div>
  )
}
```

---

## 🛡️ ROUTE PROTÉGÉE

### 9. Composant de protection

```tsx
// src/components/ProtectedRoute.tsx

import { Navigate } from 'react-router-dom'
import { AuthService } from '../services/auth.service'

interface ProtectedRouteProps {
  children: React.ReactNode
}

export function ProtectedRoute({ children }: ProtectedRouteProps) {
  if (!AuthService.isAuthenticated()) {
    return <Navigate to="/login" replace />
  }

  return <>{children}</>
}
```

### 10. Utilisation dans le routeur

```tsx
// src/App.tsx

import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { LoginPage } from './pages/Login'
import { EspacesListPage } from './pages/EspacesList'
import { ProtectedRoute } from './components/ProtectedRoute'

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <EspacesListPage />
            </ProtectedRoute>
          }
        />
      </Routes>
    </BrowserRouter>
  )
}

export default App
```

---

## 📝 TYPES TYPESCRIPT

### 11. Fichier de types centralisé

```typescript
// src/types/api.types.ts

export interface ApiResponse<T> {
  success: boolean
  data?: T
  error?: string
}

export type Role = 'DIRECTEUR_ETUDES' | 'FORMATEUR' | 'ETUDIANT'

export interface User {
  id: string
  email: string
  nom: string
  prenom: string
  role: Role
  motDePasseTemporaire: boolean
  createdAt: string
  updatedAt: string
}

// ... tous les autres types
```

---

## 🔧 GESTION D'ERREURS

### 12. Hook personnalisé pour les requêtes

```tsx
// src/hooks/useApi.ts

import { useState, useEffect } from 'react'

export function useApi<T>(apiCall: () => Promise<T>) {
  const [data, setData] = useState<T | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchData = async () => {
      try {
        const result = await apiCall()
        setData(result)
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Unknown error')
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  return { data, loading, error }
}
```

---

## 📦 INSTALLATION FRONTEND

```bash
# Dépendances recommandées
npm install react-router-dom
npm install axios  # Alternative à fetch
npm install @tanstack/react-query  # Pour le cache et la gestion d'état
```

---

**🎯 Le dev frontend a tout ce qu'il faut pour commencer ! 🚀**
