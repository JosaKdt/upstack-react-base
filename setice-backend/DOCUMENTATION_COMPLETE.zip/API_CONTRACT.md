# 📋 CONTRAT API - SETICE BACKEND

## 🔐 AUTHENTIFICATION

### Base URL
```
http://localhost:3000/api/v1
```

### Login
```http
POST /auth/login
```

**Request Body:**
```json
{
  "email": "directeur@setice.edu",
  "password": "password123"
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "user": {
      "id": "8197fd4b-d30b-4b77-b4ae-d6ba373ba1e3",
      "email": "directeur@setice.edu",
      "nom": "DIRECTEUR",
      "prenom": "Des Études",
      "role": "DIRECTEUR_ETUDES",
      "motDePasseTemporaire": false,
      "createdAt": "2025-01-05T00:00:00.000Z",
      "updatedAt": "2025-01-05T00:00:00.000Z"
    },
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  }
}
```

**Response (400 Bad Request):**
```json
{
  "success": false,
  "error": "INVALID_CREDENTIALS"
}
```

**Validation:**
- `email` : string, format email, requis
- `password` : string, min 8 caractères, requis

---

## 🔒 ROUTES PROTÉGÉES

Toutes les routes ci-dessous nécessitent un header d'authentification :

```http
Authorization: Bearer <TOKEN_JWT>
```

**Rôle requis:** `DIRECTEUR_ETUDES`

---

## 👥 FORMATEURS

### Créer un formateur
```http
POST /formateurs/create
Authorization: Bearer <TOKEN>
```

**Request Body:**
```json
{
  "nom": "DUPONT",
  "prenom": "Jean",
  "email": "jean.dupont@setice.edu",
  "specialite": "Génie Logiciel"
}
```

**Response (201 Created):**
```json
{
  "success": true,
  "data": {
    "id": "7d273c00-ccb1-46ab-8596-6e18b009bfcd",
    "nom": "DUPONT",
    "prenom": "Jean",
    "email": "jean.dupont@setice.edu",
    "specialite": "Génie Logiciel",
    "createdAt": "2025-01-05T10:00:00.000Z",
    "updatedAt": "2025-01-05T10:00:00.000Z"
  }
}
```

**Erreurs possibles:**
- `400` : Email déjà utilisé
- `401` : Non authentifié
- `403` : Rôle non autorisé

---

## 🎓 PROMOTIONS

### Créer une promotion
```http
POST /promotions/create
Authorization: Bearer <TOKEN>
```

**Request Body:**
```json
{
  "code": "L3-SIL-2025",
  "libelle": "Licence 3 Système Informatique et Logiciel 2025",
  "annee": "2024-2025"
}
```

**Response (201 Created):**
```json
{
  "success": true,
  "data": {
    "id": "8a29c572-df59-4500-ab74-5b16b5e88f32",
    "code": "L3-SIL-2025",
    "libelle": "Licence 3 Système Informatique et Logiciel 2025",
    "annee": "2024-2025",
    "createdAt": "2025-01-05T10:00:00.000Z",
    "updatedAt": "2025-01-05T10:00:00.000Z"
  }
}
```

**Erreurs possibles:**
- `400` : Code déjà existant
- `401` : Non authentifié
- `403` : Rôle non autorisé

---

## 📚 MATIÈRES

### Créer une matière
```http
POST /matieres/create
Authorization: Bearer <TOKEN>
```

**Request Body:**
```json
{
  "libelle": "Génie Logiciel",
  "code": "GE/SIL"
}
```

**Response (201 Created):**
```json
{
  "success": true,
  "data": {
    "id": "f52eab2f-c1e9-4310-a192-b12e85513179",
    "libelle": "Génie Logiciel",
    "code": "GE/SIL",
    "createdAt": "2025-01-05T10:00:00.000Z",
    "updatedAt": "2025-01-05T10:00:00.000Z"
  }
}
```

**Note:** Le champ `code` est optionnel

---

## 🎒 ÉTUDIANTS

### Créer un étudiant
```http
POST /etudiants/create
Authorization: Bearer <TOKEN>
```

**Request Body:**
```json
{
  "nom": "TEST",
  "prenom": "Etudiant",
  "email": "test.etudiant@setice.edu",
  "promotionId": "8a29c572-df59-4500-ab74-5b16b5e88f32",
  "matricule": "ET999999"
}
```

**Response (201 Created):**
```json
{
  "success": true,
  "data": {
    "id": "d8048430-8113-47c3-a8ae-0315cf404984",
    "nom": "TEST",
    "prenom": "Etudiant",
    "email": "test.etudiant@setice.edu",
    "matricule": "ET999999",
    "promotionId": "8a29c572-df59-4500-ab74-5b16b5e88f32",
    "createdAt": "2025-01-05T10:00:00.000Z",
    "updatedAt": "2025-01-05T10:00:00.000Z"
  }
}
```

**Erreurs possibles:**
- `400` : Promotion inexistante ou email déjà utilisé
- `401` : Non authentifié
- `403` : Rôle non autorisé

---

## 📖 ESPACES PÉDAGOGIQUES

### Créer un espace pédagogique
```http
POST /espaces-pedagogique/create
Authorization: Bearer <TOKEN>
```

**Request Body:**
```json
{
  "promotionId": "8a29c572-df59-4500-ab74-5b16b5e88f32",
  "matiereId": "f52eab2f-c1e9-4310-a192-b12e85513179",
  "formateurId": "7d273c00-ccb1-46ab-8596-6e18b009bfcd",
  "annee": "2024-2025"
}
```

**Response (201 Created):**
```json
{
  "success": true,
  "data": {
    "id": "c70bcc50-17ff-4ac5-82c2-f4a0d2a0bd43",
    "promotionId": "8a29c572-df59-4500-ab74-5b16b5e88f32",
    "matiereId": "f52eab2f-c1e9-4310-a192-b12e85513179",
    "formateurId": "7d273c00-ccb1-46ab-8596-6e18b009bfcd",
    "annee": "2024-2025",
    "createdAt": "2025-01-05T10:00:00.000Z",
    "updatedAt": "2025-01-05T10:00:00.000Z"
  }
}
```

---

### Lister les espaces pédagogiques
```http
GET /espaces-pedagogique/list
Authorization: Bearer <TOKEN>
```

**Response (200 OK):**
```json
{
  "success": true,
  "data": [
    {
      "id": "c70bcc50-17ff-4ac5-82c2-f4a0d2a0bd43",
      "annee": "2024-2025",
      "promotion": {
        "id": "8a29c572-df59-4500-ab74-5b16b5e88f32",
        "code": "L3-SIL-2025",
        "libelle": "Licence 3 Système Informatique et Logiciel 2025"
      },
      "matiere": {
        "id": "f52eab2f-c1e9-4310-a192-b12e85513179",
        "libelle": "Génie Logiciel",
        "code": "GE/SIL"
      },
      "formateur": {
        "id": "7d273c00-ccb1-46ab-8596-6e18b009bfcd",
        "nom": "DUPONT",
        "prenom": "Jean",
        "email": "jean.dupont@setice.edu"
      },
      "etudiants": [
        {
          "id": "d8048430-8113-47c3-a8ae-0315cf404984",
          "nom": "TEST",
          "prenom": "Etudiant",
          "matricule": "ET999999"
        }
      ]
    }
  ]
}
```

---

### Affecter un formateur
```http
POST /espaces-pedagogique/assign-formateur
Authorization: Bearer <TOKEN>
```

**Request Body:**
```json
{
  "espacePedagogiqueId": "c70bcc50-17ff-4ac5-82c2-f4a0d2a0bd43",
  "formateurId": "7d273c00-ccb1-46ab-8596-6e18b009bfcd"
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "id": "c70bcc50-17ff-4ac5-82c2-f4a0d2a0bd43",
    "formateurId": "7d273c00-ccb1-46ab-8596-6e18b009bfcd",
    "updatedAt": "2025-01-05T10:30:00.000Z"
  }
}
```

**Erreurs possibles:**
- `400` : Espace ou formateur inexistant
- `401` : Non authentifié
- `403` : Rôle non autorisé

---

### Inscrire des étudiants
```http
POST /espaces-pedagogique/add-etudiants
Authorization: Bearer <TOKEN>
```

**Request Body:**
```json
{
  "espacePedagogiqueId": "c70bcc50-17ff-4ac5-82c2-f4a0d2a0bd43",
  "promotionId": "8a29c572-df59-4500-ab74-5b16b5e88f32"
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "inscrits": 31,
    "dejaInscrits": 0,
    "total": 31
  }
}
```

**Note:** Inscrit TOUS les étudiants de la promotion. Détecte et ignore les doublons.

**Erreurs possibles:**
- `400` : Espace ou promotion inexistant
- `401` : Non authentifié
- `403` : Rôle non autorisé

---

## 🔑 CODES D'ERREUR

| Code | Message | Signification |
|------|---------|---------------|
| `200` | OK | Succès (GET, PUT, DELETE) |
| `201` | Created | Ressource créée avec succès |
| `400` | Bad Request | Données invalides ou duplicata |
| `401` | Unauthorized | Token manquant ou invalide |
| `403` | Forbidden | Rôle insuffisant |
| `404` | Not Found | Ressource inexistante |
| `500` | Internal Error | Erreur serveur |

---

## 🧪 DONNÉES DE TEST

### Compte Directeur
```
Email: directeur@setice.edu
Password: password123
Role: DIRECTEUR_ETUDES
```

### IDs de test (créés si besoin)
```
Promotion ID:    8a29c572-df59-4500-ab74-5b16b5e88f32
Matiere ID:      f52eab2f-c1e9-4310-a192-b12e85513179
Formateur ID:    7d273c00-ccb1-46ab-8596-6e18b009bfcd
Etudiant ID:     d8048430-8113-47c3-a8ae-0315cf404984
Espace ID:       c70bcc50-17ff-4ac5-82c2-f4a0d2a0bd43
```

---

## 📊 WORKFLOW TYPIQUE

```
1. POST /auth/login
   → Récupérer le token

2. POST /promotions/create
   → Créer la promotion (sauver l'ID)

3. POST /matieres/create
   → Créer la matière (sauver l'ID)

4. POST /formateurs/create
   → Créer le formateur (sauver l'ID)

5. POST /etudiants/create
   → Créer des étudiants (utiliser promotionId)

6. POST /espaces-pedagogique/create
   → Créer l'espace (utiliser les 3 IDs)

7. GET /espaces-pedagogique/list
   → Consulter les espaces

8. POST /espaces-pedagogique/add-etudiants
   → Inscrire la promotion
```

---

## 🔒 SÉCURITÉ

### Token JWT
- **Durée de vie:** 24 heures
- **Algorithme:** HS256
- **Claims:** userId, email, role
- **Header:** `Authorization: Bearer <token>`

### Validation
- Toutes les routes sont validées avec **Zod**
- Erreurs retournées au format JSON avec `success: false`

---

## 🌐 CORS

Le backend accepte les requêtes depuis n'importe quelle origine en développement.

En production, limiter aux domaines autorisés.

---

## 📝 NOTES IMPORTANTES

1. **Toutes les dates** sont en UTC ISO 8601
2. **Tous les IDs** sont des UUID v4
3. **Tous les emails** sont en lowercase
4. **Les noms** sont en UPPERCASE par convention
5. **Les prenoms** sont en Titlecase par convention
6. **Le token expire après 24h** - gérer le refresh côté frontend

---

## 🚀 PROCHAINS ENDPOINTS (Sprint 2+)

- Gestion des devoirs
- Gestion des présences
- Planning des cours
- Messagerie interne
- Tableaux de bord

---

**Version API:** 1.0.0  
**Dernière mise à jour:** 06 janvier 2025  
**Contact:** [ton email]
