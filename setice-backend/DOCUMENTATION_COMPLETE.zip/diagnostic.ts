/**
 * 🔍 SCRIPT DE DIAGNOSTIC - SETICE Backend
 * 
 * Ce script teste chaque endpoint et affiche la VRAIE réponse
 * pour comprendre pourquoi les tests échouent
 */

const BASE_URL = 'http://localhost:3000/api/v1'

async function makeRequest(method: string, endpoint: string, body?: any, useAuth: boolean = false, token?: string) {
  const headers: any = {
    'Content-Type': 'application/json',
  }

  if (useAuth && token) {
    headers['Authorization'] = `Bearer ${token}`
  }

  try {
    const response = await fetch(`${BASE_URL}${endpoint}`, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined,
    })

    const data = await response.json()
    
    return {
      status: response.status,
      statusText: response.statusText,
      data
    }
  } catch (error) {
    console.error('❌ Erreur fetch:', error)
    throw error
  }
}

async function main() {
  console.log('🔍 DIAGNOSTIC BACKEND SETICE\n')
  
  // ==========================================
  // TEST 1: LOGIN
  // ==========================================
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('🔐 TEST 1: LOGIN')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')
  
  const loginResult = await makeRequest('POST', '/auth/login', {
    email: 'directeur@setice.edu',
    password: 'password123'
  })
  
  console.log('Status:', loginResult.status, loginResult.statusText)
  console.log('Response:', JSON.stringify(loginResult.data, null, 2))
  
  let token = ''
  
  if (loginResult.data.success && loginResult.data.data) {
    token = loginResult.data.data.token
    console.log('\n✅ Token récupéré:', token.substring(0, 50) + '...')
  } else if (loginResult.data.token) {
    token = loginResult.data.token
    console.log('\n✅ Token récupéré (structure alternative):', token.substring(0, 50) + '...')
  } else {
    console.log('\n❌ Pas de token dans la réponse!')
    return
  }
  
  // ==========================================
  // TEST 2: CRÉER UN FORMATEUR (AVEC AUTH)
  // ==========================================
  console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('👥 TEST 2: CRÉER UN FORMATEUR (AVEC AUTH)')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')
  
  const formateurData = {
    nom: 'DIAGNOSTIC',
    prenom: 'Test',
    email: 'diagnostic.test@setice.edu',
    specialite: 'Testing'
  }
  
  console.log('Requête:', JSON.stringify(formateurData, null, 2))
  
  const formateurResult = await makeRequest('POST', '/formateurs/create', formateurData, true, token)
  
  console.log('\nStatus:', formateurResult.status, formateurResult.statusText)
  console.log('Response:', JSON.stringify(formateurResult.data, null, 2))
  
  // ==========================================
  // TEST 3: CRÉER UN FORMATEUR (SANS AUTH)
  // ==========================================
  console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('👥 TEST 3: CRÉER UN FORMATEUR (SANS AUTH)')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')
  
  const formateurData2 = {
    nom: 'NOAUTH',
    prenom: 'Test',
    email: 'noauth.test@setice.edu',
    specialite: 'Testing'
  }
  
  console.log('Requête (sans token):', JSON.stringify(formateurData2, null, 2))
  
  const noAuthResult = await makeRequest('POST', '/formateurs/create', formateurData2, false)
  
  console.log('\nStatus:', noAuthResult.status, noAuthResult.statusText)
  console.log('Response:', JSON.stringify(noAuthResult.data, null, 2))
  
  // ==========================================
  // TEST 4: CRÉER UNE PROMOTION
  // ==========================================
  console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('🎓 TEST 4: CRÉER UNE PROMOTION')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')
  
  const promotionData = {
    code: 'TEST-DIAG-2025',
    libelle: 'Test Diagnostic 2025',
    annee: '2024-2025'
  }
  
  console.log('Requête:', JSON.stringify(promotionData, null, 2))
  
  const promotionResult = await makeRequest('POST', '/promotions/create', promotionData, true, token)
  
  console.log('\nStatus:', promotionResult.status, promotionResult.statusText)
  console.log('Response:', JSON.stringify(promotionResult.data, null, 2))
  
  // ==========================================
  // TEST 5: LISTE DES ESPACES
  // ==========================================
  console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('📖 TEST 5: LISTE DES ESPACES')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')
  
  const listResult = await makeRequest('GET', '/espaces-pedagogique/list', undefined, true, token)
  
  console.log('\nStatus:', listResult.status, listResult.statusText)
  console.log('Response:', JSON.stringify(listResult.data, null, 2))
  
  // ==========================================
  // RÉSUMÉ
  // ==========================================
  console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('📊 RÉSUMÉ DU DIAGNOSTIC')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')
  
  console.log('✅ Tests effectués:')
  console.log('   1. Login:', loginResult.status === 200 ? '✅' : '❌')
  console.log('   2. Créer formateur (avec auth):', formateurResult.status === 201 ? '✅' : `❌ (${formateurResult.status})`)
  console.log('   3. Créer formateur (sans auth):', noAuthResult.status === 401 ? '✅' : `❌ (${noAuthResult.status})`)
  console.log('   4. Créer promotion:', promotionResult.status === 201 ? '✅' : `❌ (${promotionResult.status})`)
  console.log('   5. Liste espaces:', listResult.status === 200 ? '✅' : `❌ (${listResult.status})`)
  
  console.log('\n🔍 Points à vérifier:')
  console.log('   • Structure de réponse: data.data ou juste data ?')
  console.log('   • Middleware d\'auth: Retourne 401 ou 400 ?')
  console.log('   • Schémas Zod: Quels champs sont requis ?')
  console.log('')
}

main().catch(console.error)
