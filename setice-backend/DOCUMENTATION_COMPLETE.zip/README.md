# 🎓 SETICE - Système de Gestion Pédagogique

**Plateforme e-learning moderne pour établissements d'enseignement supérieur**

![Status](https://img.shields.io/badge/status-MVP-blue)
![Version](https://img.shields.io/badge/version-1.0.0--alpha-orange)
![License](https://img.shields.io/badge/license-MIT-green)

---

## 📋 TABLE DES MATIÈRES

- [Vision](#-vision)
- [Fonctionnalités](#-fonctionnalités)
- [Stack Technique](#-stack-technique)
- [Installation](#-installation)
- [Documentation](#-documentation)
- [Roadmap](#-roadmap)
- [Contribution](#-contribution)

---

## 🎯 VISION

> **"Créer une plateforme e-learning qui maximise l'engagement étudiant et simplifie la gestion académique"**

SETICE permet aux établissements d'enseignement supérieur de :
- ✅ Gérer leurs promotions, formateurs et étudiants
- ✅ Créer et gérer des espaces pédagogiques
- ✅ Suivre les présences et noter les devoirs
- ✅ Communiquer efficacement (messagerie, notifications)

---

## ✨ FONCTIONNALITÉS

### **Sprint 1 - Gestion Administrative** ✅

#### Directeur des Études
- [x] Créer des comptes formateurs et étudiants
- [x] Créer des promotions
- [x] Créer des espaces pédagogiques
- [x] Affecter des formateurs aux espaces
- [x] Inscrire des étudiants aux espaces
- [x] Consulter tous les espaces pédagogiques

### **Sprint 2 - Outils Pédagogiques** 🚧

#### Formateurs
- [ ] Gérer les devoirs (créer, noter)
- [ ] Enregistrer les présences
- [ ] Consulter le planning des cours
- [ ] Communiquer avec les étudiants

#### Étudiants
- [ ] Consulter leurs espaces pédagogiques
- [ ] Déposer des devoirs
- [ ] Consulter leurs notes
- [ ] Voir leur taux de présence

### **Sprints futurs** 🔮

- Messagerie interne
- Vidéo conférence
- Forum de discussion
- Quiz interactifs
- Mobile app

---

## 🛠️ STACK TECHNIQUE

### **Backend**
- **Framework** : Next.js 14 (App Router)
- **ORM** : TypeORM
- **Database** : PostgreSQL
- **Validation** : Zod
- **Auth** : JWT (bcrypt + jose)

### **Frontend** (En cours)
- **Framework** : Next.js 15
- **Styling** : Tailwind CSS + shadcn/ui
- **State** : Zustand + React Query
- **Forms** : React Hook Form + Zod
- **Icons** : Lucide React

### **DevOps**
- **CI/CD** : GitHub Actions
- **Hosting** : Vercel (frontend) + Railway (backend)
- **Database** : Supabase / Railway
- **Monitoring** : Sentry + Datadog

---

## 🚀 INSTALLATION

### **Prérequis**

- Node.js 18+
- PostgreSQL 14+
- npm ou pnpm

### **Setup Backend**

```bash
# Cloner le repo
git clone https://github.com/ton-org/setice-backend.git
cd setice-backend

# Installer les dépendances
npm install

# Configurer l'environnement
cp .env.example .env
# Éditer .env avec tes valeurs

# Lancer la base de données
# (Docker ou PostgreSQL local)

# Lancer le serveur de développement
npm run dev

# Backend disponible sur http://localhost:3000
```

### **Setup Frontend** (À venir)

```bash
cd setice-frontend
npm install
npm run dev

# Frontend disponible sur http://localhost:3001
```

---

## 📚 DOCUMENTATION

### **Pour les développeurs**

- [**API Contract**](./API_CONTRACT.md) - Documentation complète des routes API
- [**Frontend Examples**](./FRONTEND_EXAMPLES.md) - Code TypeScript prêt à l'emploi
- [**Known Issues**](./KNOWN_ISSUES.md) - Bugs connus et solutions
- [**Roadmap**](./TODO_ROADMAP.md) - Fonctionnalités à venir

### **Architecture**

```
setice-backend/
├── app/
│   └── api/
│       └── v1/
│           ├── auth/login/          # Authentification
│           ├── formateurs/          # CRUD formateurs
│           ├── promotions/          # CRUD promotions
│           ├── etudiants/           # CRUD étudiants
│           ├── matieres/            # CRUD matières
│           └── espaces-pedagogique/ # Gestion espaces
│
├── src/
│   ├── entities/      # Entités TypeORM
│   ├── repositories/  # Accès données
│   ├── services/      # Logique métier
│   ├── schemas/       # Validation Zod
│   ├── middleware/    # Auth, errors, etc.
│   └── lib/           # Utils
│
├── __tests__/         # Tests d'acceptation
└── .env               # Configuration
```

---

## 🧪 TESTS

### **Lancer les tests**

```bash
# Tests d'acceptation (Sprint 1)
npm run test:sprint1

# Tous les tests
npm test

# Coverage
npm run test:coverage
```

### **Status des tests**

- ✅ 19/40 tests passés (47.5%)
- 🐛 3 bugs critiques identifiés
- 📋 Voir [KNOWN_ISSUES.md](./KNOWN_ISSUES.md)

---

## 🗺️ ROADMAP

### **Q1 2026 (Jan-Mar)**
- [x] Sprint 1 : Backend API ✅
- [ ] MVP Frontend (en cours) 🚧
- [ ] Sprint 2 : Fonctionnalités pédagogiques
- [ ] Sprint 3 : UX/UI avancée

### **Q2 2026 (Apr-Jun)**
- [ ] Sprint 4 : Sécurité & Performance
- [ ] Sprint 5 : Déploiement production
- [ ] Features avancées (vidéo, forum, quiz)

### **Q3 2026 (Jul-Sep)**
- [ ] Application mobile
- [ ] Notifications push
- [ ] Mode offline

### **Q4 2026 (Oct-Dec)**
- [ ] IA & Automatisation
- [ ] Analytics avancés
- [ ] Marketplace de cours

📋 **Voir la roadmap complète** : [TODO_ROADMAP.md](./TODO_ROADMAP.md)

---

## 🤝 CONTRIBUTION

### **Comment contribuer ?**

1. Fork le projet
2. Créer une branche feature (`git checkout -b feature/AmazingFeature`)
3. Commit tes changements (`git commit -m 'Add AmazingFeature'`)
4. Push vers la branche (`git push origin feature/AmazingFeature`)
5. Ouvrir une Pull Request

### **Guidelines**

- Suivre les conventions de code (ESLint + Prettier)
- Écrire des tests pour les nouvelles fonctionnalités
- Mettre à jour la documentation
- Commits en anglais, PR descriptions en français

### **Code of Conduct**

- Respecter les autres contributeurs
- Accepter les feedbacks constructifs
- Communiquer clairement

---

## 📄 LICENSE

MIT License - Voir [LICENSE](./LICENSE) pour plus de détails

---

## 👥 ÉQUIPE

- **Product Owner** : [Ton nom]
- **Backend Lead** : [Ton nom]
- **Frontend Dev** : [À venir]
- **UI/UX Designer** : [À venir]

---

## 📞 SUPPORT

### **Bugs & Feature Requests**

- Ouvrir une [issue GitHub](https://github.com/ton-org/setice/issues)
- Slack : #setice-support (si workspace)
- Email : support@setice.edu

### **Documentation**

- Wiki : [GitHub Wiki](https://github.com/ton-org/setice/wiki)
- FAQ : [docs/FAQ.md](./docs/FAQ.md)
- Vidéos : [YouTube Playlist](https://youtube.com/playlist/...)

---

## 🎓 CRÉDITS

Inspiré par les meilleures pratiques de :
- Moodle (LMS open-source)
- Canvas LMS (interface moderne)
- Google Classroom (simplicité)

---

## 📊 MÉTRIQUES

### **Développement**
![GitHub issues](https://img.shields.io/github/issues/ton-org/setice)
![GitHub pull requests](https://img.shields.io/github/issues-pr/ton-org/setice)
![GitHub last commit](https://img.shields.io/github/last-commit/ton-org/setice)

### **Qualité**
![Tests](https://img.shields.io/badge/tests-47.5%25-yellow)
![Coverage](https://img.shields.io/badge/coverage-not%20measured-lightgrey)
![License](https://img.shields.io/badge/license-MIT-green)

---

## 🌟 STARS

Si ce projet t'aide, donne-lui une ⭐ sur GitHub ! Ça motive l'équipe ! 🚀

---

## 🔗 LIENS UTILES

- [Documentation API](./API_CONTRACT.md)
- [Guide Frontend](./FRONTEND_EXAMPLES.md)
- [Bugs connus](./KNOWN_ISSUES.md)
- [Roadmap](./TODO_ROADMAP.md)
- [Changelog](./CHANGELOG.md)

---

**Fait avec ❤️ pour l'éducation**

