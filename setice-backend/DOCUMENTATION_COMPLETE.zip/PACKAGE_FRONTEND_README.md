# 📦 PACKAGE FRONTEND - SETICE BACKEND

## 🎯 POUR QUI ?

Ce package est destiné à **ton développeur frontend** qui va créer l'interface utilisateur de SETICE.

---

## 📁 CONTENU DU PACKAGE

### 1. **API_CONTRACT.md** 📋
**Contrat d'API complet**
- ✅ Toutes les 9 routes avec exemples
- ✅ Format des requêtes/réponses JSON
- ✅ Codes d'erreur HTTP
- ✅ Workflow typique d'utilisation
- ✅ Données de test prêtes à l'emploi
- ✅ Notes sur la sécurité (JWT, CORS)

**Quand l'utiliser ?**  
Référence permanente pour savoir comment appeler chaque endpoint.

---

### 2. **FRONTEND_EXAMPLES.md** 💻
**Code TypeScript prêt à copier-coller**
- ✅ Service API générique (`ApiService`)
- ✅ Service d'authentification (`AuthService`)
- ✅ Services métier (Espaces, Promotions, Formateurs, etc.)
- ✅ Composants React d'exemple (Login, Liste)
- ✅ Hook personnalisé pour les requêtes
- ✅ Route protégée (ProtectedRoute)
- ✅ Types TypeScript complets

**Quand l'utiliser ?**  
Point de départ pour implémenter les appels API dans le frontend.

---

## 🚀 UTILISATION

### Étape 1 : Lire le contrat API
```bash
# Ouvrir dans VS Code ou ton éditeur préféré
code API_CONTRACT.md
```

**Comprendre :**
- Comment se connecter (login)
- Comment lister les espaces
- Comment créer des entités
- Quels headers envoyer

---

### Étape 2 : Intégrer le code TypeScript
```bash
# Copier les services dans ton projet frontend
# Structure recommandée :
src/
├── services/
│   ├── api.service.ts          # Service de base
│   ├── auth.service.ts         # Authentification
│   ├── espaces.service.ts      # Espaces pédagogiques
│   ├── promotions.service.ts   # Promotions
│   └── ...
├── components/
│   └── ProtectedRoute.tsx      # Route protégée
├── pages/
│   ├── Login.tsx               # Page de connexion
│   └── EspacesList.tsx         # Liste des espaces
└── types/
    └── api.types.ts            # Types centralisés
```

---

### Étape 3 : Configurer l'URL de base

Dans `api.service.ts`, modifier :
```typescript
const API_BASE_URL = 'http://localhost:3000/api/v1'
// En production : 'https://api.setice.com/api/v1'
```

---

### Étape 4 : Installer les dépendances

```bash
npm install react-router-dom
npm install @tanstack/react-query  # Optionnel mais recommandé
```

---

### Étape 5 : Tester la connexion

```typescript
// Test rapide dans la console du navigateur
import { AuthService } from './services/auth.service'

AuthService.login('directeur@setice.edu', 'password123')
  .then(user => console.log('Connecté:', user))
  .catch(err => console.error('Erreur:', err))
```

---

## 🧪 DONNÉES DE TEST

### Compte de test disponible
```
Email: directeur@setice.edu
Password: password123
Role: DIRECTEUR_ETUDES
```

### IDs de test (dans la base de données)
```
Promotion ID:    8a29c572-df59-4500-ab74-5b16b5e88f32
Matiere ID:      f52eab2f-c1e9-4310-a192-b12e85513179
Formateur ID:    7d273c00-ccb1-46ab-8596-6e18b009bfcd
Etudiant ID:     d8048430-8113-47c3-a8ae-0315cf404984
Espace ID:       c70bcc50-17ff-4ac5-82c2-f4a0d2a0bd43
```

---

## 🔐 AUTHENTIFICATION JWT

### Flow d'authentification

1. **Login** : `POST /auth/login`
   → Reçoit un token JWT

2. **Stocker le token** : `localStorage.setItem('setice_token', token)`

3. **Ajouter aux requêtes** : `Authorization: Bearer <token>`

4. **Token expire** : après 24 heures
   → Rediriger vers login si 401

### Exemple de gestion du token

```typescript
// Intercepter les erreurs 401
fetch(url, options)
  .then(response => {
    if (response.status === 401) {
      // Token expiré, rediriger vers login
      AuthService.logout()
      window.location.href = '/login'
    }
    return response.json()
  })
```

---

## 📊 WORKFLOW TYPIQUE

### Scénario : Directeur crée un espace pédagogique

```typescript
// 1. Login
const user = await AuthService.login('directeur@setice.edu', 'password123')

// 2. Créer une promotion
const promotion = await PromotionsService.create({
  code: 'L3-IA-2025',
  libelle: 'Licence 3 Intelligence Artificielle',
  annee: '2024-2025'
})

// 3. Créer une matière
const matiere = await MatieresService.create({
  libelle: 'Machine Learning',
  code: 'ML/L3'
})

// 4. Créer un formateur
const formateur = await FormateursService.create({
  nom: 'MARTIN',
  prenom: 'Sophie',
  email: 'sophie.martin@setice.edu',
  specialite: 'Intelligence Artificielle'
})

// 5. Créer l'espace pédagogique
const espace = await EspacesService.create({
  promotionId: promotion.id,
  matiereId: matiere.id,
  formateurId: formateur.id,
  annee: '2024-2025'
})

// 6. Inscrire la promotion
const result = await EspacesService.addEtudiants(
  espace.id,
  promotion.id
)

console.log(`${result.inscrits} étudiants inscrits!`)
```

---

## 🎨 STACK RECOMMANDÉ

### Frontend
- **Framework** : React 18+ ou Next.js 14+
- **Routing** : React Router v6
- **State** : React Query + Context API
- **Styling** : Tailwind CSS
- **Forms** : React Hook Form + Zod

### TypeScript
- **Strict mode** : activé
- **Types** : fournis dans FRONTEND_EXAMPLES.md

---

## 🐛 GESTION D'ERREURS

### Erreurs courantes

#### ❌ CORS Error
```
Access to fetch at 'http://localhost:3000' has been blocked by CORS
```
**Solution** : Le backend doit autoriser ton domaine frontend

#### ❌ 401 Unauthorized
```
{ success: false, error: "UNAUTHORIZED" }
```
**Solution** : Token manquant, invalide ou expiré → Refaire le login

#### ❌ 403 Forbidden
```
{ success: false, error: "FORBIDDEN" }
```
**Solution** : Rôle insuffisant (seul DIRECTEUR_ETUDES peut créer)

#### ❌ 400 Bad Request
```
{ success: false, error: "Email déjà utilisé" }
```
**Solution** : Validation échouée, corriger les données

---

## 📚 RESSOURCES SUPPLÉMENTAIRES

### Documentation
- API Contract : `API_CONTRACT.md`
- Code Examples : `FRONTEND_EXAMPLES.md`

### Support
- Backend tourne sur : `http://localhost:3000`
- Postman collection : [demander au backend dev]
- Swagger (bientôt) : `/api-docs`

---

## 🎯 CHECKLIST FRONTEND

### Avant de commencer
- [ ] Lire `API_CONTRACT.md` en entier
- [ ] Comprendre le flow d'authentification JWT
- [ ] Tester les endpoints dans Postman/Insomnia
- [ ] Vérifier que le backend tourne

### Développement
- [ ] Copier les services TypeScript
- [ ] Adapter l'URL de base (dev vs prod)
- [ ] Implémenter la page de login
- [ ] Implémenter les routes protégées
- [ ] Gérer l'expiration du token (401)
- [ ] Afficher les erreurs utilisateur (400, 403)

### Tests
- [ ] Tester le login avec le compte test
- [ ] Tester la création d'une promotion
- [ ] Tester la liste des espaces
- [ ] Tester l'expiration du token

---

## 💡 CONSEILS POUR LE DEV FRONTEND

### 1. **Commence par l'authentification**
Implémente d'abord le login et la gestion du token. Tout le reste en dépend.

### 2. **Utilise React Query**
Ça simplifie énormément la gestion du cache et des états de chargement.

```bash
npm install @tanstack/react-query
```

### 3. **Centralise la gestion d'erreurs**
Crée un hook `useApiError` pour afficher les erreurs de manière cohérente.

### 4. **Mock les données en attendant**
Si le backend n'est pas encore prêt, utilise les données de test du contrat.

### 5. **TypeScript strict**
Active le mode strict, les types fournis sont complets et te guideront.

---

## 🚀 NEXT STEPS

### Sprint 1 (Backend complet)
✅ Toutes les routes sont prêtes
✅ Authentification JWT fonctionnelle
✅ Tests d'acceptation passés

### Sprint 2 (Frontend)
- [ ] Interface de login
- [ ] Dashboard directeur
- [ ] Liste des espaces
- [ ] Création d'entités (formulaires)
- [ ] Gestion des erreurs

---

## 📞 CONTACT

**Questions sur l'API ?**  
Contacte le backend developer (toi!) 😊

**Bugs backend ?**  
Crée un ticket avec :
- Route concernée
- Requête envoyée (curl/fetch)
- Réponse reçue
- Comportement attendu

---

**🎉 Tout est prêt pour démarrer le frontend ! Good luck! 🚀**
